To install SXVF-H9:

1. Plug in camera to computer.
2. When a driver dialog box pops up, select "Install from a list or specific
location (Advanced)". Then click next.
3. On the next screen, select "Search for the best driver in these locations.".
Deselect the "Search removable media". Then select "Include this location in
the search:". Click on the browse button and find the directory where this
README is located. Finally press Next.
4. The dialog box will then look in the directory and search for the driver,
ending at a screen that states "The wizard has finished installing the software
for:"
5. To check if the driver was installed, select the start menu, and then right
click on "My Computer", selecting "Properties" from the pop up box. In the
window that opens, select the "Hardware" tab, and then "Device Manager" (it
should be the first button on the tab page). This will spawn a new window. If
the name "BlockIOClass" exists, and there is an item under it that says
"Starlight Xpress USB 2.0 SXV-H9 Camera Driver", then the camera has been
installed successfully.
6. The camera user software can now be installed by opening the "SXV-H9 Camera
Software" folder located with this README and double clicking "SETUP.EXE".
7. To use the LabVIEW software, create a new VI and copy the needed subVIs from
into your program. Save the program to the same location as the subVI files. A
sample VI that will run the camera is called "test.vi" in this directory. 

This part is optional but highly recommended!

8. To install the VIs system wide, open "C:\Program Files\National
Instruments\LabVIEW 8.6\vi.lib\" (or the equivalent for the version of
labview). Create the folder "Starlight Xpress" here. Then copy over all of the
files in "SXVF-H9 LabVIEW" to the new "Starlight Xpress" folder. 
9. Finally, to add them to the tool palette in LabVIEW, open any VI and select
from the menu bar "Tools->Advanced->Edit Palette Set...". Then right click on a
blank space in the functions palette and select "Insert->Subpalette...". Then
select the bubble "Link to a directory", press OK, and select the "C:\Program
Files\National Instruments\LabVIEW 8.6\vi.lib\Starlight Xpress" (or equivalent)
folder. Finally click "Save Changes" on the "Edit Controls and Functions
Palette Set" dialog box. 
