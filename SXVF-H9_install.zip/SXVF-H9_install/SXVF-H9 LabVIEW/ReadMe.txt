The core VIs are the CCD action VIs, including

CCD Open:   initialize the CCD.
CCD Reset:  put CCD in a known configuration.
CCD Expose Pixels:  Expose the CCD for a finite time. It automatically clear the 	pixels before the exposure. The unit for time duration is millisecond, but the 	absolute time accuracy is more than tens of millisecond. It supports exposure 	of a sub-frame (range options) and on chip binning (bin options)
CCD Read Pixels: Obtain the data from CCD after the exposure. The imput are the number 	of points in x and y direction, which should be consistent with the exposure 	settings, namely, range/bin.
CCD Close:  close the CCD 

Present Directory sets the directory that all the VIs are, and are used in simplifier file naming and finding the files.

One program of general use is the easy vedio vi, which uses all the above vis, and capature the CCD image continuously. It takes several seconds to obtain a full frame, but can be much faster if the pixels are binned. Use the round stop button in the VI rather than that in the toolbar to terminate the vi to ensure that the CCD is correctly closed.

Create Darkframe.vi creates a dark frame.

Vedio&record same the images and extract spectra save 2 1D information.


IMPORTANT:
To use all the VIs,you should put the library file sxusbcam.dll in the same directory as the labview files.  Also, you should put the files sxvio.inf and sxvio.sys in the directory "system disk"/WINNT/inf and the file 05472131.HEX in the directory "system disk"/WINNT/system32/drivers.
   
 